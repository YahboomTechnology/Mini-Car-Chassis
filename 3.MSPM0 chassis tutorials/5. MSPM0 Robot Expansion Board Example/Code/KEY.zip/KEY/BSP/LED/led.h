#ifndef	__LED_H__
#define __LED_H__

#include "ti_msp_dl_config.h"

void LED_Toggle(void);
void LED_ON(void);
void LED_OFF(void);

#endif
