#ifndef	__TIMER_H__
#define __TIMER_H__

#include "ti_msp_dl_config.h"
#include "usart.h"
#include "key.h"

uint32_t Get_Time(void);


#endif
